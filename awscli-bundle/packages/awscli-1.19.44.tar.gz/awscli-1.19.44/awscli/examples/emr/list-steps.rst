The following command lists all of the steps in a cluster with the cluster ID ``j-3SD91U2E1L2QX``::

  aws emr list-steps --cluster-id j-3SD91U2E1L2QX
