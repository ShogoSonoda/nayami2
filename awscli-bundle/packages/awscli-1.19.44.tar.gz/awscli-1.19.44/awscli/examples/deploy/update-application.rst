**To change details of an application**

The following ``update-application`` example changes the name of an application that is associated with the user's AWS account. ::

    aws deploy update-application \
        --application-name WordPress_App \
        --new-application-name My_WordPress_App

This command produces no output.
