**To delete an HSM configuration**

The following ``delete-hsm-configuration`` example deletes the specified HSM configuration from the current AWS account. ::

    aws redshift delete-hsm-configuration /
        --hsm-configuration-identifier myhsmconnection

This command does not produce any output.
